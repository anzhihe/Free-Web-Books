

### 1.7.6 - 26/11/2015

 Changes: 


 * Documentation, review and github links
 * #21 customizer fonts issue fixed

fixed issue
 * Merge pull request #22 from Gouravwp/development

#21 customizer fonts issue fixed


### 1.7.5 - 19/10/2015

 Changes: 


 * Updated spanish translation again
 * Merge pull request #18 from RAVMN/development

Updated spanish translation


### 1.7.4 - 16/07/2015

 Changes: 


 * Update class-tgm-plugin-activation to latest version
 * Update style.css
